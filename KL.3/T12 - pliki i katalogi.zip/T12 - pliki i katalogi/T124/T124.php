<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>T124</title>
</head>
<body>
<table>
    <tr>
        <td>Imię i naziwsko:</td>
        <td>Klasa/grupa:</td>
        <td>Data:</td>
    </tr>
    <tr>
        <td>Łukasz Iwaniec</td>
        <td>3ip_02</td>
        <td>30.11.2023</td>
    </tr>
</table>
<hr>
<h2>T124</h2>

<br><br>
<p>
    Plik napisy.txt zawiera 1000 liczb binarnych zapisanych w oddzielnych wierszach. Napisz skrypt, który odczyta te
    liczby i wypisze je na ekranie w następującej postaci:

    <br>Nr_liczby – liczba_binarna – liczba_dziesiętna
</p>
<br>
<?php

$plik = file('napisy.txt');

$i = 1;
foreach ($plik as $el){
    $pom = bindec($el);
    echo "$i - $el - $pom<br>";
    $i++;
}

?>
</body>
</html>
